#! /bin/bash

CONFIG_PATH=`dirname $0`
. $CONFIG_PATH/config.sh

rm ../$DB
